"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

// ❌ المسار القديم اللي بيعمل الخطأ:
// import { registerSchema, RegisterInput } from "@/lib/validations/auth";

// ✅ المسار الصحيح (حسب تسمية ملفاتك):
import { registerSchema, RegisterInput } from "@/lib/validators/auth.schema";

import FormInput from "@/components/shared/FormInput";
import Link from "next/link";

export default function RegisterPage() {
  const { register, handleSubmit, formState: { errors } } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
  });

  const onSubmit = (data: RegisterInput) => {
    console.log("بيانات التسجيل:", data);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
      <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-md space-y-4 rounded-xl bg-white p-8 shadow-lg">
        <h2 className="text-center text-3xl font-extrabold text-blue-600">إنشاء حساب</h2>
        
        <FormInput label="الاسم الكامل" register={register("name")} error={errors.name?.message} placeholder="أحمد محمد" />
        <FormInput label="البريد الإلكتروني" type="email" register={register("email")} error={errors.email?.message} placeholder="example@mail.com" />
        
        <div className="flex flex-col gap-1">
          <label className="text-sm font-semibold text-gray-700">نوع الحساب</label>
          <select {...register("role")} className="p-2 border rounded-md border-gray-300 outline-none focus:border-blue-500">
            <option value="STUDENT">طالب</option>
            <option value="TEACHER">معلم</option>
          </select>
          {errors.role && <span className="text-xs text-red-500">{errors.role.message}</span>}
        </div>

        <FormInput label="كلمة المرور" type="password" register={register("password")} error={errors.password?.message} placeholder="******" />
        <FormInput label="تأكيد كلمة المرور" type="password" register={register("confirmPassword")} error={errors.confirmPassword?.message} placeholder="******" />

        <button type="submit" className="w-full rounded-md bg-blue-600 py-3 font-bold text-white hover:bg-blue-700 transition-all">
          تسجيل حساب جديد
        </button>

        <p className="text-center text-sm text-gray-600">
          لديك حساب بالفعل؟ <Link href="/login" className="text-blue-600 hover:underline">سجل دخولك</Link>
        </p>
      </form>
    </div>
  );
}
