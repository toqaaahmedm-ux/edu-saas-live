import Navbar from "@/components/layout/Navbar";
import { Sidebar } from "@/components/layout/Sidebar";

export default function StudentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex h-screen w-full bg-white overflow-hidden">
      {/* السايد بار ثابت عاليمين */}
      <aside className="h-full w-64 flex-shrink-0 border-l bg-white hidden md:block">
        <Sidebar />
      </aside>

      {/* الجزء المتبقي */}
      <div className="flex-1 flex flex-col min-w-0 h-full">
        <header className="w-full bg-white border-b sticky top-0 z-20">
          <Navbar />
        </header>

        {/* الماين: جعلناه flex واستخدمنا justify-center لتوسط المحتوى أفقياً */}
        <main className="flex-1 overflow-y-auto bg-gray-50/50 flex justify-center p-6 md:p-12">
          {/* الحاوية دي هي اللي شايلة الأسئلة ومخليين عرضها محكوم عشان متفرشش في الشاشة */}
          <div className="w-full max-w-5xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
