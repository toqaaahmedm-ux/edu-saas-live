// src/app/(dashboard)/student/page.tsx
import { BookOpen, Clock, Award } from "lucide-react";

export default function StudentPage() {
  const stats = [
    { label: "كورس مشترك به", value: "12", icon: <BookOpen className="text-blue-600" />, color: "bg-blue-100" },
    { label: "ساعات التعلم", value: "48", icon: <Clock className="text-green-600" />, color: "bg-green-100" },
    { label: "شهادة مكتملة", value: "3", icon: <Award className="text-purple-600" />, color: "bg-purple-100" },
  ];

  return (
    <div className="space-y-8">
      {/* قسم الترحيب */}
      <div>
        <h2 className="text-2xl font-bold text-gray-800">أهلاً بك مجدداً يا بطل 👋</h2>
        <p className="text-gray-500">استكمل رحلتك التعليمية من حيث توقفت.</p>
      </div>

      {/* الإحصائيات - Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 transition-hover hover:shadow-md">
            <div className={`p-4 rounded-xl ${stat.color}`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">{stat.label}</p>
              <h3 className="text-2xl font-bold text-gray-800">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>
      
      {/* هنا هنضيف "آخر الكورسات" في الخطوة الجاية (صفحة 19) */}
    </div>
  );
}


