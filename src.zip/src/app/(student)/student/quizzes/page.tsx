"use client";
import { useQuizStore } from "@/store/useQuizStore";
import { QuizTimer } from "@/components/student/QuizTimer";
import { useEffect } from "react";

const mockQuestions = [
  { id: "q1", question: "ما هو العظم الأطول في جسم الإنسان؟", options: ["الجمجمة", "الفخذ", "العمود الفقري", "العضد"], correct: 1 },
  { id: "q2", question: "كم عدد صمامات القلب؟", options: ["2", "3", "4", "5"], correct: 2 }
];

export default function QuizPage() {
  const { currentIndex, nextQuestion, prevQuestion, skipQuestion, setAnswer, answers, isStarted, startQuiz } = useQuizStore();

  useEffect(() => {
    if (!isStarted) startQuiz(30 * 60);
  }, [isStarted, startQuiz]);

  const currentQ = mockQuestions[currentIndex];

  if (!currentQ) return (
    <div className="flex items-center justify-center min-h-[60vh] w-full px-4">
      <div className="text-center bg-white p-12 rounded-3xl shadow-xl border max-w-md w-full">
        <h2 className="text-3xl font-black text-blue-600 mb-4">انتهى الاختبار! 🎉</h2>
        <p className="text-gray-500">جاري معالجة نتيجتك...</p>
      </div>
    </div>
  );

  return (
    /* ✅ التعديل الأساسي: إضافة flex و justify-center لضمان توسط المحتوى */
    <div className="w-full min-h-full py-8 md:py-12 flex justify-center bg-gray-50/50" dir="rtl">
      
      {/* ✅ تحديد max-w-4xl و mx-auto و w-full للتحكم في العرض والتمركز */}
      <div className="w-full max-w-4xl mx-auto px-4 md:px-0 flex flex-col gap-6 md:gap-8">
        
        {/* الهيدر العلوي */}
        <div className="bg-white p-6 md:p-8 rounded-2xl shadow-md border border-gray-100 flex justify-between items-center w-full">
          <div className="text-right">
            <p className="text-blue-600 font-bold text-xs md:text-sm mb-1 uppercase tracking-tight">جامعة عين شمس - Faculty of Medicine</p>
            <h2 className="text-xl md:text-3xl font-black text-gray-800">
              السؤال {currentIndex + 1} <span className="text-gray-300 mx-2">/</span> {mockQuestions.length}
            </h2>
          </div>
          <div className="bg-blue-50 px-3 py-1.5 md:px-4 md:py-2 rounded-xl">
             <QuizTimer />
          </div>
        </div>

        {/* كرت السؤال */}
        <div className="bg-white p-6 md:p-16 rounded-[32px] md:rounded-[40px] shadow-lg border border-gray-100 w-full min-h-[400px] flex flex-col">
          <h3 className="text-xl md:text-4xl font-bold text-gray-800 mb-8 md:mb-12 text-right leading-relaxed">
            {currentQ.question}
          </h3>

          {/* الإجابات */}
          <div className="grid grid-cols-1 gap-3 md:gap-4 w-full flex-1">
            {currentQ.options.map((opt, i) => {
              const isSelected = answers[currentQ.id] === i.toString();
              return (
                <button
                  key={i}
                  onClick={() => setAnswer(currentQ.id, i.toString())}
                  className={`flex items-center justify-between p-4 md:p-6 rounded-2xl border-2 transition-all duration-200 ${
                    isSelected
                      ? "border-blue-600 bg-blue-50/50 text-blue-900 shadow-sm scale-[1.01]"
                      : "border-gray-100 bg-white hover:border-blue-200 text-gray-600"
                  }`}
                >
                  <div className="flex items-center gap-4 md:gap-6">
                    <span className={`w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center font-black text-lg md:text-xl border-2 ${
                      isSelected ? "bg-blue-600 text-white border-blue-600" : "bg-gray-50 text-gray-400 border-gray-100"
                    }`}>
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="text-lg md:text-2xl font-medium">{opt}</span>
                  </div>
                  {isSelected && <div className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-blue-600 flex items-center justify-center text-white text-[10px] md:text-xs">✓</div>}
                </button>
              );
            })}
          </div>

          {/* أزرار التحكم */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 mt-12 md:mt-16 pt-8 border-t border-gray-100">
            <button
              disabled={currentIndex === 0}
              onClick={prevQuestion}
              className="w-full md:w-auto px-8 py-4 rounded-xl font-bold text-gray-400 disabled:opacity-30 hover:bg-gray-50 transition-all"
            >
              السابق
            </button>
            
            <div className="flex w-full md:w-auto gap-3 md:gap-4">
              <button
                onClick={skipQuestion}
                className="flex-1 md:flex-none px-6 md:px-8 py-4 rounded-xl border-2 border-orange-100 text-orange-600 font-bold hover:bg-orange-50 transition-all"
              >
                تخطي ⏩
              </button>
              <button
                onClick={nextQuestion}
                className={`flex-1 md:flex-none px-8 md:px-12 py-4 rounded-xl font-black text-white shadow-lg transition-all active:scale-95 ${
                  currentIndex === mockQuestions.length - 1 ? "bg-green-600 shadow-green-100" : "bg-blue-600 shadow-blue-100"
                }`}
              >
                {currentIndex === mockQuestions.length - 1 ? "إنهاء الاختبار" : "التالي ➡️"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
