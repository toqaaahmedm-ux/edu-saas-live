import "./globals.css"; // تأكدي من استدعاء ملف الـ CSS

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-gray-50">
        {/* هنا نضع المحتوى، و Next.js سيتعامل مع الـ Layouts الفرعية تلقائياً */}
        {children}
      </body>
    </html>
  );
}
