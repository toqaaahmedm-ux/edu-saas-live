import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-white">
      <h1 className="text-4xl font-bold text-blue-600 mb-4">EduSaaS Platform</h1>
      <p className="text-gray-600 mb-8">مرحباً بكِ في منصة جامعة عين شمس التعليمية</p>
      <div className="flex gap-4">
        <Link href="/login" className="px-6 py-2 border rounded-md">تسجيل الدخول</Link>
        <Link href="/register" className="px-6 py-2 bg-blue-600 text-white rounded-md">إنشاء حساب</Link>
      </div>
    </div>
  );
}
