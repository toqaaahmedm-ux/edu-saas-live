"use client"; // ضروري لعمل المكون في Next.js 14+

const Navbar = () => {
  return (
    /* nav بياخد العرض الكامل w-full ويتوزع فيه العناصر بالتساوي */
    <nav className="w-full flex items-center justify-between px-8 py-4 bg-white">
      {/* جهة اليمين: اسم المنصة */}
      <div className="text-2xl font-black text-blue-600 tracking-tight">
        EduSaaS
      </div>

      {/* جهة اليسار: بيانات المستخدم */}
      <div className="flex items-center gap-4">
        <div className="flex flex-col text-right">
          <span className="text-sm font-bold text-gray-800">تقى محمد</span>
          <span className="text-xs text-green-500 font-medium">متصل الآن • طالب</span>
        </div>
        
        {/* الصورة الشخصية (Avatar) */}
        <div className="w-11 h-11 rounded-xl bg-blue-100 flex items-center justify-center text-xl shadow-sm border border-blue-50">
          👤
        </div>
      </div>
    </nav>
  );
};

// ✅ هذا هو السطر الأهم الذي يحل مشكلة الـ Runtime Error
export default Navbar;
