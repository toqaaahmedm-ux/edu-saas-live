"use client"; // ضروري جداً لأننا نستخدم usePathname
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const sidebarItems = [
    { label: 'لوحة التحكم', href: '/student/dashboard', icon: '🏠' },
    { label: 'كورساتي', href: '/student/courses', icon: '📚' },
    { label: 'الاختبارات', href: '/student/quizzes', icon: '📝' }, // إضافات مقترحة
    { label: 'الشهادات', href: '/student/certificates', icon: '🎓' },
];

export const Sidebar = () => {
    const pathname = usePathname();

    return (
        <aside className="w-64 bg-white border-r h-screen sticky top-0 p-4 hidden md:block">
            <div className="text-2xl font-bold mb-10 text-blue-600 px-2">EduSaaS</div>
            <nav className="space-y-2">
                {sidebarItems.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link 
                            key={item.href} 
                            href={item.href} 
                            className={`flex items-center p-3 rounded-xl transition-all ${
                                isActive 
                                ? "bg-blue-600 text-white shadow-md" 
                                : "text-gray-600 hover:bg-blue-50"
                            }`}
                        >
                            <span className="ml-3 text-lg">{item.icon}</span>
                            <span className="font-medium">{item.label}</span>
                        </Link>
                    );
                })}
            </nav>
        </aside>
    );
};
