"use client";
interface CertificateProps { name: string; score: number; }

export const Certificate = ({ name, score }: CertificateProps) => {
  return (
    <div id="certificate" className="w-[800px] h-[560px] p-10 bg-white border-[15px] border-blue-900 relative shadow-2xl mx-auto">
      <div className="border-4 border-yellow-600 h-full p-8 flex flex-col items-center text-center">
        <h1 className="text-5xl font-serif text-blue-900 mb-4">CERTIFICATE</h1>
        <p className="text-xl italic mb-8">This is to certify that</p>
        <h2 className="text-4xl font-bold border-b-2 border-blue-900 px-10 pb-2 mb-6">{name}</h2>
        <p className="text-lg leading-relaxed mb-6">
          Has successfully passed the <b>Anatomy Medical Examination</b><br />
          with a score of <span className="text-2xl text-yellow-600">{score}%</span>
        </p>
        <div className="flex justify-between w-full mt-10 px-10">
          <div className="text-center border-t border-gray-400 pt-2 w-40">Date</div>
          <div className="text-center border-t border-gray-400 pt-2 w-40">Signature</div>
        </div>
      </div>
    </div>
  );
};
