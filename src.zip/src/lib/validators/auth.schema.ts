import * as z from "zod";

/**
 * Login Schema
 * مسؤول عن التحقق من بيانات تسجيل الدخول
 */
export const loginSchema = z.object({
  email: z.string().email("البريد الإلكتروني غير صالح"),
  password: z.string().min(6, "كلمة المرور يجب أن تكون 6 أحرف على الأقل"),
});

/**
 * Register Schema
 * مسؤول عن التحقق من بيانات إنشاء حساب جديد
 */
export const registerSchema = z
  .object({
    name: z.string().min(3, "الاسم يجب أن يكون 3 أحرف على الأقل"),
    email: z.string().email("البريد الإلكتروني غير صالح"),
    password: z.string().min(6, "كلمة المرور قصيرة جداً"),
    confirmPassword: z.string(),
  role: z.enum(["STUDENT", "TEACHER", "ADMIN"] as const, {
    required_error: "يرجى اختيار نوع الحساب",
}),

  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "كلمات المرور غير متطابقة",
    path: ["confirmPassword"], // بيظهر الخطأ عند حقل تأكيد كلمة المرور
  });

/**
 * Types Extraction
 * استخراج الأنواع لاستخدامها في المكونات (Components)
 */
export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
