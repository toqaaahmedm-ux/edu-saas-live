import { create } from "zustand";
import { persist } from "zustand/middleware";

// تعريف شكل البيانات (Types)
interface QuizState {
  currentIndex: number;
  answers: Record<string, string>; // ID السؤال : الإجابة المختارة
  timeRemaining: number;
  isStarted: boolean;
  
  // الأفعال (Actions)
  startQuiz: (time: number) => void;
  setAnswer: (questionId: string, value: string) => void;
  nextQuestion: () => void;
  prevQuestion: () => void;
  skipQuestion: () => void; // ميزة الـ Skip اللي طلبناها
  tick: () => void;
  resetQuiz: () => void;
}

export const useQuizStore = create<QuizState>()(
  persist(
    (set) => ({
      currentIndex: 0,
      answers: {},
      timeRemaining: 3600,
      isStarted: false,

      startQuiz: (time) => set({ isStarted: true, timeRemaining: time, currentIndex: 0, answers: {} }),

      setAnswer: (id, val) =>
        set((state) => ({
          answers: { ...state.answers, [id]: val },
        })),

      nextQuestion: () => set((state) => ({ currentIndex: state.currentIndex + 1 })),

      prevQuestion: () => set((state) => ({ currentIndex: state.currentIndex - 1 })),

      skipQuestion: () => set((state) => ({ currentIndex: state.currentIndex + 1 })),

      tick: () =>
        set((state) => ({
          timeRemaining: state.timeRemaining > 0 ? state.timeRemaining - 1 : 0,
        })),

      resetQuiz: () => set({ currentIndex: 0, answers: {}, isStarted: false }),
    }),
    { name: "quiz-storage" } // دي عشان تحفظ البيانات في المتصفح (Persistence)
  )
);
